/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.prog2_exer7;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aquin
 */
public class Products_1 extends javax.swing.JFrame {
    String[][] prod = new String[100][7];
    int x=0;
    
public int[] selectedRowIndices;

public String getValueAt(int rowIndex, int columnIndex) {
    return (String) jTable1.getValueAt(rowIndex, columnIndex);
}

public int[] getSelectedRowIndices() {
    return selectedRowIndices;
}

private Customers customersInstance;

    public Products_1(Customers customersInstance) {
        initComponents();
        this.customersInstance = customersInstance;
    }  
    
public void decrementProductQuantity(String selectedProductID) {
    for (int i = 0; i < x; i++) {
        if (prod[i][0].equals(selectedProductID)) {
            int currentQuantity = stringtoInt(prod[i][4]);
            if (currentQuantity > 0) {
                currentQuantity--;
                prod[i][4] = currentQuantity + "";
                break; 
            }
        }
    }
    refresh_my_table(); // Refresh the table after updating the quantity
    writeToCSVp(prod, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\products.csv");
}

public void incrementProductQuantity(String selectedProductID) {
    for (int i = 0; i < x; i++) {
        if (prod[i][0].equals(selectedProductID)) {
            int currentQuantity = stringtoInt(prod[i][4]);
            currentQuantity++;
            prod[i][4] = Integer.toString(currentQuantity);
            break;
        }
    }
refresh_my_table();
writeToCSVp(prod, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\products.csv");
}

public String[][] readCsvProducts(String filePath) {
    String[][] values = null; // 2D array to hold values
    int rows = 0;
    BufferedReader br = null;
    try {
        br = new BufferedReader(new FileReader(filePath));
        String line;
        // Count the number of non-empty rows in the CSV file
        while ((line = br.readLine()) != null) {
            if (line.trim().length() > 0) {
                rows++;
            }
        }
        // Initialize the values array with the correct number of rows
        values = new String[rows][];

        // Reset the BufferedReader to start reading from the beginning of the file
        br.close();
        br = new BufferedReader(new FileReader(filePath));

        int row = 0;
        while ((line = br.readLine()) != null) {
            // Skip processing if the line is empty or contains only whitespace
            if (line.trim().length() == 0) {
                continue;
            }
            // Split the line by commas
            String[] rowValues = line.split(",");

            // Assign row values directly without removing quotes
            values[row++] = rowValues;
        }
    } catch (IOException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (br != null) {
                br.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    return values;
}

private void loadProductsData(String[][] customerData) {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // Clear existing rows
    
    // Clear the existing data in the cust array
    x = 0;
    
    // Add the loaded customer data to the cust array and table
    for (String[] row : customerData) {
        // Add row to the cust array
        prod[x++] = row;
        // Add row to the table model
        model.addRow(row);
    }
}


public void writeToCSVp(String[][] data, String filePath) {
    try (FileWriter writer = new FileWriter(filePath)) {
        for (String[] row : data) {
            if (row != null && row.length > 0) { // Check if the row is not null and not empty
                for (int i = 0; i < row.length; i++) {
                    // Check if the current cell is not null
                    if (row[i] != null) {
                        // Write the field as is
                        writer.append(row[i]);
                    }
                    // Add a comma if it's not the last cell in the row and the next cell is not null
                    if (i < row.length - 1 && row[i + 1] != null) {
                        writer.append(",");
                    }
                }
                // Add a new line after each row
                writer.append("\n");
            }
        }
        writer.flush();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

private void loadDataFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            // If the file exists, read data from it and load the product data
            String[][] csvProducts = readCsvProducts(filePath);
            loadProductsData(csvProducts);
        } catch (IOException e) {
            // If the file does not exist or cannot be read, print an error message
            System.out.println(e);
        }
    }

private String filePath;

    /**
     * Creates new form Products
     */
    public Products_1(String filePath) {
        initComponents();
        this.filePath = filePath; // Store the file path
        selectedRowIndices = new int[100];
        loadDataFromFile(); // Load data from the CSV file
    }
    public Products_1() {
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ProdSupp = new javax.swing.JTextField();
        labelprodtype = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        labelproddater = new javax.swing.JLabel();
        ProdID = new javax.swing.JTextField();
        ProdType = new javax.swing.JTextField();
        labelprodquantity = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        ProdQuantity = new javax.swing.JTextField();
        labelproddesc = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        ProdDesc = new javax.swing.JTextField();
        labelprodcost = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        ProdCost = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        ProdDateReceived = new javax.swing.JTextField();
        labelprodsupp = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        labelprodid = new javax.swing.JLabel();
        SaveBTNP = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        EditBTNP = new javax.swing.JButton();
        DeleteBTNP = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        ProdSupp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProdSuppKeyReleased(evt);
            }
        });

        labelprodtype.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        labelprodtype.setText(".");

        jLabel10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 102));
        jLabel10.setText("Quantity:");

        labelproddater.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelproddater.setText("e.g. mm/dd/yyyy");

        ProdID.setEditable(false);
        ProdID.setText("1");
        ProdID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProdIDKeyReleased(evt);
            }
        });

        ProdType.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProdTypeKeyReleased(evt);
            }
        });

        labelprodquantity.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelprodquantity.setText("e.g. must be a number");

        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 102));
        jLabel6.setText("Prod Desc:");

        ProdQuantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProdQuantityKeyReleased(evt);
            }
        });

        labelproddesc.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        labelproddesc.setText(".");

        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 51, 102));
        jLabel12.setText("Total Cost:");

        ProdDesc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProdDescKeyReleased(evt);
            }
        });

        labelprodcost.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelprodcost.setText("e.g. must be a number");

        jLabel8.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 102));
        jLabel8.setText("Supplier:");

        ProdCost.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProdCostKeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Product Information Systems");
        jLabel1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jLabel1KeyPressed(evt);
            }
        });

        ProdDateReceived.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProdDateReceivedKeyReleased(evt);
            }
        });

        labelprodsupp.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        labelprodsupp.setText(".");

        jLabel4.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("Prod Type:");

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 102));
        jLabel2.setText("Prod ID:");

        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 51, 102));
        jLabel14.setText("Date Received:");

        labelprodid.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        labelprodid.setText(".");

        SaveBTNP.setBackground(new java.awt.Color(0, 51, 102));
        SaveBTNP.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        SaveBTNP.setForeground(new java.awt.Color(255, 255, 255));
        SaveBTNP.setText("Save");
        SaveBTNP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBTNPActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Prod ID", "Type", "Prod Desc", "Supplier", "Quantity", "Total Cost", "Received"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        EditBTNP.setBackground(new java.awt.Color(0, 51, 102));
        EditBTNP.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        EditBTNP.setForeground(new java.awt.Color(255, 255, 255));
        EditBTNP.setText("Update");
        EditBTNP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBTNPActionPerformed(evt);
            }
        });

        DeleteBTNP.setBackground(new java.awt.Color(0, 51, 102));
        DeleteBTNP.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        DeleteBTNP.setForeground(new java.awt.Color(255, 255, 255));
        DeleteBTNP.setText("Delete");
        DeleteBTNP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBTNPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10)
                            .addComponent(jLabel12)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(ProdCost)
                            .addComponent(ProdQuantity, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ProdSupp, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ProdDesc, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ProdType, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ProdID)
                            .addComponent(ProdDateReceived, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelprodcost, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labelproddater, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labelprodquantity, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelproddesc)
                                    .addComponent(labelprodsupp)
                                    .addComponent(labelprodtype)
                                    .addComponent(labelprodid, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(80, 80, 80)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addComponent(SaveBTNP)
                                .addGap(18, 18, 18)
                                .addComponent(EditBTNP)
                                .addGap(18, 18, 18)
                                .addComponent(DeleteBTNP)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 541, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(labelprodid)
                            .addComponent(ProdID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(labelprodtype)
                            .addComponent(ProdType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(labelproddesc)
                            .addComponent(ProdDesc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(labelprodsupp)
                            .addComponent(ProdSupp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(labelprodquantity)
                            .addComponent(ProdQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(labelprodcost)
                            .addComponent(ProdCost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(labelproddater)
                            .addComponent(ProdDateReceived, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SaveBTNP)
                            .addComponent(EditBTNP)
                            .addComponent(DeleteBTNP))))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1KeyPressed

    private void ProdIDKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProdIDKeyReleased
        String prodid = ProdID.getText().trim();
    boolean isValid = true;
    int maxInput = 6;
    if (prodid.length() == maxInput) {
        for (int i = 0; i < prodid.length(); i++) {
            char currentChar = prodid.charAt(i);
            if (!Character.isDigit(currentChar)) {
                isValid = false;
                break;
            }
            }
        } else {
                isValid = false;
        }
    if (isValid) {
        labelprodid.setForeground(Color.green);
        labelprodid.setText("Valid ID");
    } else {
        labelprodid.setForeground(Color.red);
        labelprodid.setText("Invalid ID");
    }     
    }//GEN-LAST:event_ProdIDKeyReleased

    private void ProdQuantityKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProdQuantityKeyReleased
        String prodquantity = ProdQuantity.getText().trim();
    boolean isValid = true;
    int whitespace = prodquantity.indexOf(" ");
    int maxInput = 3;
    if (prodquantity.length() <= maxInput && prodquantity.length() > 0) {
        for (int i = 0; i < prodquantity.length(); i++) {
            char currentChar = prodquantity.charAt(i);
                if (whitespace > 0) {
                isValid = false;
                break;
                }
            if (!Character.isDigit(currentChar)) {
                isValid = false;
                break;
            }
        } 
            } else {
                isValid = false;
        }
    if (isValid) {
        labelprodquantity.setForeground(Color.green);
        labelprodquantity.setText("Valid Quantiy");
    } else {
        labelprodquantity.setForeground(Color.red);
        labelprodquantity.setText("Invalid Quantity");
    }  
    }//GEN-LAST:event_ProdQuantityKeyReleased

    private void ProdCostKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProdCostKeyReleased
        String prodcost = ProdCost.getText().trim();
    boolean isValid = true;
    int whitespace = prodcost.indexOf(" ");
    int maxInput = 5;
    if (prodcost.length() <= maxInput && prodcost.length() > 0) {
        for (int i = 0; i < prodcost.length(); i++) {
            char currentChar = prodcost.charAt(i);
                if (whitespace > 0) {
                isValid = false;
                break;
                }
                if (!Character.isDigit(currentChar)) {
                isValid = false;
                break;
                }
            }
            } else {
                isValid = false;
        }
    if (isValid) {
        labelprodcost.setForeground(Color.green);
        labelprodcost.setText("Valid Cost");
    } else {
        labelprodcost.setForeground(Color.red);
        labelprodcost.setText("Invalid Cost");
    }  
    }//GEN-LAST:event_ProdCostKeyReleased

    private void ProdDateReceivedKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProdDateReceivedKeyReleased
    String proddatereceived = ProdDateReceived.getText().trim();
        boolean isValid = true;

        if (proddatereceived.charAt(2) == '/' && proddatereceived.charAt(5) == '/' && proddatereceived.length() == 10) {        
        for (int i = 0; i < proddatereceived.length(); i++) {
            char currentChar = proddatereceived.charAt(i);
        
            if(i == 2 && currentChar == '/') {
                continue;
            }
            if(i == 5 && currentChar == '/') {
                continue;
            }
            if (!Character.isDigit(currentChar)) {
            isValid = false;
            break;
            }
        }        
        } else {
            isValid = false;
                }
        
        if (isValid) {
            labelproddater.setForeground(Color.green);
            labelproddater.setText("Valid Date");
        } else{
            labelproddater.setForeground(Color.red);
            labelproddater.setText("Invalid Date");
        }
    }//GEN-LAST:event_ProdDateReceivedKeyReleased

    private void ProdTypeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProdTypeKeyReleased
        String prodtype = ProdType.getText().trim();
        boolean isValid = false;

        for (int i = 0; i < prodtype.length(); i++) {
            char currentChar = prodtype.charAt(i);
            if (!Character.isDigit(currentChar) && currentChar > 0) {
                isValid = true;
                break;
            }                        
        }
    if (isValid) {
        labelprodtype.setForeground(Color.green);
        labelprodtype.setText("Valid Type");
    } else {
        labelprodtype.setForeground(Color.red);
        labelprodtype.setText("Invalid Type");
    }    
    }//GEN-LAST:event_ProdTypeKeyReleased

    private void ProdDescKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProdDescKeyReleased
        String proddesc = ProdDesc.getText().trim();
        boolean isValid = false;

        for (int i = 0; i < proddesc.length(); i++) {
            char currentChar = proddesc.charAt(i);
            if (!Character.isDigit(currentChar) && currentChar > 0) {
                isValid = true;
                break;
            }                        
        }
    if (isValid) {
        labelproddesc.setForeground(Color.green);
        labelproddesc.setText("Valid Description");
    } else {
        labelproddesc.setForeground(Color.red);
        labelproddesc.setText("Invalid Description");
    }  
    }//GEN-LAST:event_ProdDescKeyReleased

    private void ProdSuppKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProdSuppKeyReleased
        String prodsupp = ProdSupp.getText().trim();
        boolean isValid = false;

        for (int i = 0; i < prodsupp.length(); i++) {
            char currentChar = prodsupp.charAt(i);
            if (!Character.isDigit(currentChar) && currentChar > 0) {
                isValid = true;
                break;
            }                        
        }
    if (isValid) {
        labelprodsupp.setForeground(Color.green);
        labelprodsupp.setText("Valid Supplier");
    } else {
        labelprodsupp.setForeground(Color.red);
        labelprodsupp.setText("Invalid Supplier");
    }  
    }//GEN-LAST:event_ProdSuppKeyReleased
private int getNextAvailableIdp() {
    int nextId = 1;

    boolean found;
    for (int i = 0; true; nextId++) {
        found = false;
        for (i = 0; i < x; i++) {
            int currentId = stringtoInt(prod[i][0]);
            if (currentId == nextId) {
                found = true; 
                break;
            }
        }
        if (!found) {
            break; 
        }
    }

    return nextId;
}
private int stringtoInt(String s) {
    int result = 0;
    for (int i = 0; i < s.length(); i++) {
        char c = s.charAt(i);
        if (Character.isDigit(c)) {
            result = result * 10 + (c - '0');
        } 
    }
    return result;
}
    private void SaveBTNPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBTNPActionPerformed
    DefaultTableModel tblmodel= (DefaultTableModel) jTable1.getModel();
    
    if(x==0)
        tblmodel.setRowCount(0);
    
    int newIDp = getNextAvailableIdp();

    prod[x][0]=""+newIDp;
    prod[x][1]=ProdType.getText();
    prod[x][2]=ProdDesc.getText();
    prod[x][3]=ProdSupp.getText();
    prod[x][4]=ProdQuantity.getText();
    prod[x][5]=ProdCost.getText();
    prod[x][6]=ProdDateReceived.getText(); //code for save button
   
//        boolean validation = true;
        boolean emptytextfield = false;
        if (ProdID.getText().length() == 0){
            emptytextfield = true;
        }
        if (ProdType.getText().length() == 0){
            emptytextfield = true;
        }
        if (ProdDesc.getText().length() == 0){
            emptytextfield = true;
        }        
        if (ProdSupp.getText().length() == 0){
            emptytextfield = true;
        }         
        if (ProdQuantity.getText().length() == 0){
            emptytextfield = true;
        }         
        if (ProdCost.getText().length() == 0){
            emptytextfield = true;
        }
        if (ProdDateReceived.getText().length() == 0){
            emptytextfield = true;
        }        
       
        
        if (emptytextfield){
            messagebox3("Input cannot be empty", "Error");//code for save button
            return;      
        }
        boolean validation = true;
        if (!labelprodtype.getText().equals("Valid Type")){
            validation = false;
        }
        if (!labelproddesc.getText().equals("Valid Description")){
            validation = false;
        }
        if (!labelprodsupp.getText().equals("Valid Supplier")){
            validation = false;
        }        
        if (!labelprodquantity.getText().equals("Valid Quantiy")){
            validation = false;
        }         
        if (!labelprodcost.getText().equals("Valid Cost")){
            validation = false;
        }         
        if (!labelproddater.getText().equals("Valid Date")){
            validation = false;
            }

    if (validation){
        tblmodel.addRow(prod[x]);           //code for save button
        x++;
        writeToCSVp(prod, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\products.csv");

//        ProdID.setText(x+1+"");
    } else {
        messagebox4("Invalid Output", "Error");   
    }
refresh_my_table();    
//    messagebox2("Save?", "Are you sure?");
    }//GEN-LAST:event_SaveBTNPActionPerformed
    private void messagebox3(String msg, String tittlebar) {
        JOptionPane.showMessageDialog(null,msg,tittlebar,JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void messagebox4(String msg, String tittlebar) {
        JOptionPane.showMessageDialog(null,msg,tittlebar,JOptionPane.INFORMATION_MESSAGE);
    }
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
    ProdID.setEditable(false); //Code for unable to edit Customer ID
    }//GEN-LAST:event_formWindowOpened
public void refresh_my_table(){
   DefaultTableModel tblmodel= (DefaultTableModel) jTable1.getModel();
   tblmodel.setRowCount(0);
   for(int row=0; row<x;row++){
       tblmodel.addRow(prod[row]);
   } //clear or refresh the table
}
    private void EditBTNPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBTNPActionPerformed
        boolean emptytextfield = false;
        if (ProdID.getText().length() == 0){
            emptytextfield = true;
        }
        if (ProdType.getText().length() == 0){
            emptytextfield = true;
        }
        if (ProdDesc.getText().length() == 0){
            emptytextfield = true;
        }
        if (ProdSupp.getText().length() == 0){
            emptytextfield = true;
        }        
        if (ProdQuantity.getText().length() == 0){
            emptytextfield = true;
        }         
        if (ProdDateReceived.getText().length() == 0){
            emptytextfield = true;
        }         
        if (ProdCost.getText().length() == 0){
            emptytextfield = true;
        }
        
        if (emptytextfield){
            messagebox3("Input cannot be empty", "Error");//code for save button
            return;      
        }
        boolean validation = true;
        if (!labelprodtype.getText().equals("Valid Type")){
            validation = false;
        }
        if (!labelproddesc.getText().equals("Valid Description")){
            validation = false;
        }
        if (!labelprodsupp.getText().equals("Valid Supplier")){
            validation = false;
        }        
        if (!labelprodquantity.getText().equals("Valid Quantiy")){
            validation = false;
        }         
        if (!labelprodcost.getText().equals("Valid Cost")){
            validation = false;
        }         
        if (!labelproddater.getText().equals("Valid Date")){
            validation = false;
            }

    if (validation){
        for(int row=0;row<x;row++){
            if(prod[row][0].equals(ProdID.getText())){
                prod[row][1]=ProdType.getText();
                prod[row][2]=ProdDesc.getText();
                prod[row][3]=ProdSupp.getText();
                prod[row][4]=ProdQuantity.getText();
                prod[row][5]=ProdCost.getText();
        }
    }
        refresh_my_table(); 
        writeToCSVp(prod, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\products.csv");
    } else {
        messagebox4("Invalid Input", "Error");
        refresh_my_table();
    }
//code for Edit Button
    }//GEN-LAST:event_EditBTNPActionPerformed

    private void DeleteBTNPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBTNPActionPerformed
String idToDelete = ProdID.getText();
    
    // Find the index of the row to delete
    int rowToDelete = -1;
    for(int row = 0; row < x; row++) {
        if(prod[row][0].equals(idToDelete)) {
            rowToDelete = row;
            break;
        }
    }
    
    // If the row is found, remove it and shift subsequent rows
    if(rowToDelete != -1) {
        // Shift subsequent rows up
        for (int i = rowToDelete; i < x - 1; i++) {
            prod[i] = prod[i + 1];
        }
        // Clear the last row after shifting
        prod[x - 1] = new String[7];
        x--;
        
        // Write the updated data to the CSV file
        refresh_my_table();
        writeToCSVp(prod, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\products.csv");
    } else {
        // If the row with the given ID is not found, show an error message
        messagebox4("Customer ID not found", "Error");
    }//problem is it wont update the file when the program deletes
    }//GEN-LAST:event_DeleteBTNPActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
    int[] selectRow = jTable1.getSelectedRows();

    ProdID.setText(jTable1.getValueAt(selectRow[0], 0).toString());
    ProdType.setText(jTable1.getValueAt(selectRow[0], 1).toString());
    ProdDesc.setText(jTable1.getValueAt(selectRow[0], 2).toString());
    ProdSupp.setText(jTable1.getValueAt(selectRow[0], 3).toString());
    ProdQuantity.setText(jTable1.getValueAt(selectRow[0], 4).toString());
    ProdCost.setText(jTable1.getValueAt(selectRow[0], 5).toString());
    ProdDateReceived.setText(jTable1.getValueAt(selectRow[0], 6).toString());
    
    labelprodtype.setForeground(Color.green);
    labelprodtype.setText("Valid Type");
    labelproddesc.setForeground(Color.green);
    labelproddesc.setText("Valid Description");
    labelprodsupp.setForeground(Color.green);
    labelprodsupp.setText("Valid Supplier");
    labelprodquantity.setForeground(Color.green);
    labelprodquantity.setText("Valid Quantiy");
    labelprodcost.setForeground(Color.green);
    labelprodcost.setText("Valid Cost");
    labelproddater.setForeground(Color.green);
    labelproddater.setText("Valid Date");
    
    selectedRowIndices = jTable1.getSelectedRows();
    
refresh_my_table();
    }//GEN-LAST:event_jTable1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Products_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Products_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Products_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Products_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Products_1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeleteBTNP;
    private javax.swing.JButton EditBTNP;
    private javax.swing.JTextField ProdCost;
    private javax.swing.JTextField ProdDateReceived;
    private javax.swing.JTextField ProdDesc;
    private javax.swing.JTextField ProdID;
    private javax.swing.JTextField ProdQuantity;
    private javax.swing.JTextField ProdSupp;
    private javax.swing.JTextField ProdType;
    private javax.swing.JButton SaveBTNP;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelprodcost;
    private javax.swing.JLabel labelproddater;
    private javax.swing.JLabel labelproddesc;
    private javax.swing.JLabel labelprodid;
    private javax.swing.JLabel labelprodquantity;
    private javax.swing.JLabel labelprodsupp;
    private javax.swing.JLabel labelprodtype;
    // End of variables declaration//GEN-END:variables
}
