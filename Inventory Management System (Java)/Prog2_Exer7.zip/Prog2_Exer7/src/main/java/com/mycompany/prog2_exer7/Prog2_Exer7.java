/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog2_exer7;

/**
 *
 * @author aquin
 */
public class Prog2_Exer7 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
