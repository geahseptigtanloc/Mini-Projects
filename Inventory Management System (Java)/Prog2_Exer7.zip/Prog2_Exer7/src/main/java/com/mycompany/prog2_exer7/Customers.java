/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.prog2_exer7;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author aquin
 */
public class Customers extends javax.swing.JFrame {
    String[][] cust = new String[100][7];
    int x=0;
    String[][] ord = new String [100][8];
    int y=0;
    
    private int currentOrderIndex = 0;

 private int[] selectedRowIndices;
    private Products_1 productsInstance;

    public void setSelectedRowIndices(int[] selectedRowIndices) {
        this.selectedRowIndices = selectedRowIndices;
    }

    public void setProductsInstance(Products_1 productsInstance) {
        this.productsInstance = productsInstance;
    }
    
private String custID;

//public String[][] getOrd() {
//    return ord;
//}


//public String selectedProductID;
//public String getselectedProductID(){
//    return selectedProductID;
//};

public String[][] readCsvCustomers(String filePath) {
    String[][] values = null; // 2D array to hold values
    int rows = 0;
    BufferedReader br = null;
    try {
        br = new BufferedReader(new FileReader(filePath));
        String line;
        // Count the number of non-empty rows in the CSV file
        while ((line = br.readLine()) != null) {
            if (line.trim().length() > 0) {
                rows++;
            }
        }
        // Initialize the values array with the correct number of rows
        values = new String[rows][];

        // Reset the BufferedReader to start reading from the beginning of the file
        br.close();
        br = new BufferedReader(new FileReader(filePath));

        int row = 0;
        while ((line = br.readLine()) != null) {
            // Skip processing if the line is empty or contains only whitespace
            if (line.trim().length() == 0) {
                continue;
            }
            // Split the line by commas
            String[] rowValues = line.split(",");

            // Assign row values directly without removing quotes
            values[row++] = rowValues;
        }
    } catch (IOException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (br != null) {
                br.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    return values;
}

private void loadCustomerData(String[][] customerData) {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // Clear existing rows
    
    // Clear the existing data in the cust array
    x = 0;
    
    // Add the loaded customer data to the cust array and table
    for (String[] row : customerData) {
        // Add row to the cust array
        cust[x++] = row;
        // Add row to the table model
        model.addRow(row);
    }
}

public void writeToCSV(String[][] data, String filePath) {
    try (FileWriter writer = new FileWriter(filePath)) {
        for (String[] row : data) {
            if (row != null && row.length > 0) { // Check if the row is not null and not empty
                for (int i = 0; i < row.length; i++) {
                    // Check if the current cell is not null
                    if (row[i] != null) {
                        // Write the field as is
                        writer.append(row[i]);
                    }
                    // Add a comma if it's not the last cell in the row and the next cell is not null
                    if (i < row.length - 1 && row[i + 1] != null) {
                        writer.append(",");
                    }
                }
                // Add a new line after each row
                writer.append("\n");
            }
        }
        writer.flush();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

public String[][] readCsvOrders(String filePath) {
    String[][] values = null; // 2D array to hold values
    int rows = 0;
    BufferedReader br = null;
    try {
        br = new BufferedReader(new FileReader(filePath));
        String line;
        // Count the number of non-empty rows in the CSV file
        while ((line = br.readLine()) != null) {
            if (line.trim().length() > 0) {
                rows++;
            }
        }
        // Initialize the values array with the correct number of rows
        values = new String[rows][];

        // Reset the BufferedReader to start reading from the beginning of the file
        br.close();
        br = new BufferedReader(new FileReader(filePath));

        int row = 0;
        while ((line = br.readLine()) != null) {
            // Skip processing if the line is empty or contains only whitespace
            if (line.trim().length() == 0) {
                continue;
            }
            // Split the line by commas
            String[] rowValues = line.split(",");

            // Assign row values directly without removing quotes
            values[row++] = rowValues;
        }
    } catch (IOException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (br != null) {
                br.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    return values;
}

private void loadOrdersData(String[][] ordersData) {
    DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
    model.setRowCount(0); // Clear existing rows
    
    // Clear the existing data in the ord array
    y = 0;
    
    // Add the loaded orders data to the ord array and table
    for (String[] row : ordersData) {
        // Add row to the ord array
        ord[y++] = row;
        // Add row to the table model
        model.addRow(row);
    }
}


public void writeToCSVOrders(String[][] data, String filePath) {
    try (FileWriter writer = new FileWriter(filePath)) {
        for (String[] row : data) {
            if (row != null && row.length > 0) { // Check if the row is not null and not empty
                for (int i = 0; i < row.length; i++) {
                    // Check if the current cell is not null
                    if (row[i] != null) {
                        // Write the field as is
                        writer.append(row[i]);
                    }
                    // Add a comma if it's not the last cell in the row and the next cell is not null
                    if (i < row.length - 1 && row[i + 1] != null) {
                        writer.append(",");
                    }
                }
                // Add a new line after each row
                writer.append("\n");
            }
        }
        writer.flush();
    } catch (IOException e) {
        e.printStackTrace();
    }
}


    /**
     * Creates new form Customers
     */
    public Customers() {
        initComponents();
        jTable2.getColumnModel().getColumn(7).setMinWidth(0);
        jTable2.getColumnModel().getColumn(7).setMaxWidth(0);
        jTable2.getColumnModel().getColumn(7).setWidth(0);
        //Customers reading
        String filePath = "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\customers.csv";
    
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            // If the file exists, read data from it and load the customer data
            String[][] csvCustomers = readCsvCustomers(filePath);
            loadCustomerData(csvCustomers);
        } catch (IOException e) {
            // If the file does not exist or cannot be read, print an error message
            System.out.println("Error reading customers CSV file: " + e.getMessage());
        }
    }
    
  

    /**I have
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        SaveBTN = new javax.swing.JButton();
        CustID = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        labelname = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        CustName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        CustAddress = new javax.swing.JTextField();
        labelphone = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        CustPhone = new javax.swing.JTextField();
        labelemail = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        CustEmail = new javax.swing.JTextField();
        labelbday = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        CustBdayDate = new javax.swing.JTextField();
        labelgender = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        CustGender = new javax.swing.JTextField();
        labeladdress = new javax.swing.JLabel();
        EditBTN = new javax.swing.JButton();
        DeleteBTN = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        AddOrder = new javax.swing.JButton();
        DeleteOrder = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ProductsMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 0, 0));
        jLabel1.setText("Cust Id:");

        SaveBTN.setBackground(new java.awt.Color(102, 0, 0));
        SaveBTN.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        SaveBTN.setForeground(new java.awt.Color(255, 255, 255));
        SaveBTN.setText("Save");
        SaveBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBTNActionPerformed(evt);
            }
        });

        CustID.setEditable(false);
        CustID.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        CustID.setText("1");
        CustID.setToolTipText("");
        CustID.setDoubleBuffered(true);
        CustID.setDragEnabled(true);
        CustID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustIDActionPerformed(evt);
            }
        });
        CustID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustIDKeyReleased(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 0, 0));
        jLabel2.setText("Customer Information Systems");

        labelname.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelname.setText("e.g. Igtanloc, Geah C.");

        jLabel4.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 0, 0));
        jLabel4.setText("Cust Name:");

        CustName.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        CustName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustNameActionPerformed(evt);
            }
        });
        CustName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustNameKeyReleased(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 0, 0));
        jLabel6.setText("Cust Address:");

        CustAddress.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        CustAddress.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustAddressKeyReleased(evt);
            }
        });

        labelphone.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelphone.setText("e.g. 0912-1234567");

        jLabel8.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 0, 0));
        jLabel8.setText("Cust Phone:");

        CustPhone.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        CustPhone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustPhoneKeyReleased(evt);
            }
        });

        labelemail.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelemail.setText("e.g. text@text.com");

        jLabel10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(102, 0, 0));
        jLabel10.setText("Cust Email:");

        CustEmail.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        CustEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustEmailActionPerformed(evt);
            }
        });
        CustEmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustEmailKeyReleased(evt);
            }
        });

        labelbday.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelbday.setText("e.g. mm/dd/yyyy");

        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(102, 0, 0));
        jLabel12.setText("Cust Bday:");

        CustBdayDate.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        CustBdayDate.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustBdayDateKeyReleased(evt);
            }
        });

        labelgender.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labelgender.setText("e.g. Male/Female/Others");

        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(102, 0, 0));
        jLabel14.setText("Cust Gender:");

        CustGender.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        CustGender.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustGenderKeyReleased(evt);
            }
        });

        labeladdress.setFont(new java.awt.Font("Bahnschrift", 3, 12)); // NOI18N
        labeladdress.setText("e.g. Paris- France");

        EditBTN.setBackground(new java.awt.Color(102, 0, 0));
        EditBTN.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        EditBTN.setForeground(new java.awt.Color(255, 255, 255));
        EditBTN.setText("Update");
        EditBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBTNActionPerformed(evt);
            }
        });

        DeleteBTN.setBackground(new java.awt.Color(102, 0, 0));
        DeleteBTN.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        DeleteBTN.setForeground(new java.awt.Color(255, 255, 255));
        DeleteBTN.setText("Delete");
        DeleteBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBTNActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Cust ID", "Name", "Address", "Phone", "Email", "Bday", "Gender"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        AddOrder.setBackground(new java.awt.Color(102, 0, 0));
        AddOrder.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        AddOrder.setForeground(new java.awt.Color(255, 255, 255));
        AddOrder.setText("Add Order");
        AddOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddOrderActionPerformed(evt);
            }
        });

        DeleteOrder.setBackground(new java.awt.Color(102, 0, 0));
        DeleteOrder.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        DeleteOrder.setForeground(new java.awt.Color(255, 255, 255));
        DeleteOrder.setText("Delete Order");
        DeleteOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteOrderActionPerformed(evt);
            }
        });

        jTable2.setFont(new java.awt.Font("Segoe UI Variable", 0, 12)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Prod ID", "Type", "Prod Desc", "Quantity", "Cost", "Received", "Total Cost", "Cust ID"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jMenu1.setText("Forms");

        ProductsMenuItem.setForeground(new java.awt.Color(0, 51, 102));
        ProductsMenuItem.setText("Products");
        ProductsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductsMenuItemActionPerformed(evt);
            }
        });
        jMenu1.add(ProductsMenuItem);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(CustBdayDate, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel1)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel12)
                                            .addComponent(jLabel14))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(CustEmail, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                                                    .addComponent(CustPhone, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(CustAddress, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(CustName, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(CustID, javax.swing.GroupLayout.Alignment.LEADING)))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(12, 12, 12)
                                                .addComponent(CustGender)))))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(labeladdress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(labelname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(labelphone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(labelemail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(labelbday, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(labelgender, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addComponent(SaveBTN)
                                .addGap(24, 24, 24)
                                .addComponent(EditBTN)
                                .addGap(18, 18, 18)
                                .addComponent(DeleteBTN))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(78, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(AddOrder, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
                    .addComponent(DeleteOrder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 686, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(164, 164, 164))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(CustID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(labelname, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(labeladdress, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(labelphone))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10)
                            .addComponent(labelemail))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustBdayDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12)
                            .addComponent(labelbday))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(labelgender))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SaveBTN)
                            .addComponent(EditBTN)
                            .addComponent(DeleteBTN)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(AddOrder)
                        .addGap(18, 18, 18)
                        .addComponent(DeleteOrder)))
                .addGap(12, 15, Short.MAX_VALUE))
        );

        labeladdress.getAccessibleContext().setAccessibleName("Address");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ProductsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductsMenuItemActionPerformed
    String productsFilePath = "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\products.csv";
    Products_1 abc = new Products_1(productsFilePath);
    abc.setVisible(true);
    setProductsInstance(abc);
    }//GEN-LAST:event_ProductsMenuItemActionPerformed

    private void CustIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustIDActionPerformed
private int getNextAvailableId() {

    int nextId = 1;

    boolean found;
    for (int i = 0; true; nextId++) {
        found = false; 
        for (i = 0; i < x; i++) {
            int currentId = stringtoInt(cust[i][0]);
            if (currentId == nextId) {
                found = true;
                break;
            }
        }
        if (!found) {
            break; 
        }
    }
    return nextId;
}

//method gets called to parse integer from string
private int stringtoInt(String s) {
    int result = 0;
    for (int i = 0; i < s.length(); i++) {
        char c = s.charAt(i);
        if (Character.isDigit(c)) {
            result = result * 10 + (c - '0');
        } 
    }
    return result;
}
    private void SaveBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBTNActionPerformed
    DefaultTableModel tblmodel= (DefaultTableModel) jTable1.getModel();
    
    if(x==0)
        tblmodel.setRowCount(0);
    
    int newID = getNextAvailableId();
    
    cust[x][0]=""+newID;
    cust[x][1]=CustName.getText();
    cust[x][2]=CustAddress.getText();
    cust[x][3]=CustPhone.getText();
    cust[x][4]=CustEmail.getText();
    cust[x][5]=CustBdayDate.getText();
    cust[x][6]=CustGender.getText(); //code for save button
   
//        boolean validation = true;
        boolean emptytextfield = false;
        if (CustID.getText().length() == 0){
            emptytextfield = true;
        }
        if (CustName.getText().length() == 0){
            emptytextfield = true;
        }
        if (CustAddress.getText().length() == 0){
            emptytextfield = true;
        }
        if (CustPhone.getText().length() == 0){
            emptytextfield = true;
        }        
        if (CustEmail.getText().length() == 0){
            emptytextfield = true;
        }         
        if (CustBdayDate.getText().length() == 0){
            emptytextfield = true;
        }         
        if (CustGender.getText().length() == 0){
            emptytextfield = true;
        }
        
        if (emptytextfield){
            messagebox1("Input cannot be empty", "Error");//code for save button
            return;      
        }
        boolean validation = true;
        if (!labelname.getText().equals("Valid Name")){
            validation = false;
        }
        if (!labeladdress.getText().equals("Valid Address")){
            validation = false;
        }
        if (!labelphone.getText().equals("Good phone number")){
            validation = false;
        }        
        if (!labelemail.getText().equals("Good Email")){
            validation = false;
        }         
        if (!labelbday.getText().equals("Valid Date")){
            validation = false;
        }         
        if (!labelgender.getText().equals("Valid Gender")){
            validation = false;
            }

    if (validation){
        tblmodel.addRow(cust[x]);           //code for save button
        x++;
        writeToCSV(cust, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\customers.csv");
//        CustID.setText(""+x+1);
    } else {
        messagebox2("Invalid Output", "Error");   
    }
refresh_my_table(); 
//    messagebox2("Save?", "Are you sure?");
    }//GEN-LAST:event_SaveBTNActionPerformed
    private void messagebox1(String msg, String tittlebar) {
        JOptionPane.showMessageDialog(null,msg,tittlebar,JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void messagebox2(String msg, String tittlebar) {
        JOptionPane.showMessageDialog(null,msg,tittlebar,JOptionPane.INFORMATION_MESSAGE);
    }
    private void CustEmailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustEmailKeyReleased
    String email = CustEmail.getText().trim();
        boolean isValid = false;
        int atIndex = email.indexOf('@');
        int dotIndex = email.indexOf(".com");
        if (atIndex > 0 && dotIndex > (atIndex+3))
        isValid = true;

            if (isValid) {
            labelemail.setForeground(Color.green);
            labelemail.setText("Good Email");
        } else{
            labelemail.setForeground(Color.red);
            labelemail.setText("Bad Email");
        }
    }//GEN-LAST:event_CustEmailKeyReleased

    private void CustPhoneKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustPhoneKeyReleased
    String phone = CustPhone.getText().trim();
    boolean isValid = true;
    
    if (phone.length() == 12 && phone.charAt(4) == '-') {
    for (int i = 0; i < phone.length(); i++) {
        char currentChar = phone.charAt(i);
        
        if (i == 4 && currentChar == '-') {
            continue;
        }
        if (!Character.isDigit(currentChar)) {
            isValid = false;
            break;
        }
    }
    } else {
        isValid = false;
    }

    if (isValid) {
        labelphone.setForeground(Color.green);
        labelphone.setText("Good phone number");
    } else {
        labelphone.setForeground(Color.red);
        labelphone.setText("Bad phone number");
    }
    }//GEN-LAST:event_CustPhoneKeyReleased

    private void CustGenderKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustGenderKeyReleased
    String gender = CustGender.getText().trim();
        boolean isValid = false;
        int maleIndex = gender.indexOf("Male");
        int femaleIndex = gender.indexOf("Female");
        int othersIndex = gender.indexOf("Others");
        
        if (maleIndex >= 0) {
            isValid = true;
        } else if (femaleIndex >= 0) {
                isValid = true;
                    }else if (othersIndex >= 0) {
                        isValid = true;
                        } 
        
        for (int i = 0; i < gender.length(); i++) {
            char currentChar = gender.charAt(i);
            
        if (Character.isDigit(currentChar)) {
            isValid = false;
            break;
        }
            }
            if (isValid) {
            labelgender.setForeground(Color.green);
            labelgender.setText("Valid Gender");
        } else{
            labelgender.setForeground(Color.red);
            labelgender.setText("Invalid Gender");
        } 
    }//GEN-LAST:event_CustGenderKeyReleased

    private void CustIDKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustIDKeyReleased
//        String customerid = CustID.getText().trim();
//    boolean isValid = true;
//    int maxInput = 6;
//    if (customerid.length() == maxInput) {
//        for (int i = 0; i < customerid.length(); i++) {
//            char currentChar = customerid.charAt(i);
//            if (!Character.isDigit(currentChar)) {
//                isValid = false;
//                break;
//            }
//            }
//        } else {
//                isValid = false;
//        }
//    if (isValid) {
//        labelid.setForeground(Color.green);
//        labelid.setText("Valid ID");
//    } else {
//        labelid.setForeground(Color.red);
//        labelid.setText("Invalid ID");
//    } //disabled for exer3
    }//GEN-LAST:event_CustIDKeyReleased

    private void CustNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustNameKeyReleased
String name = CustName.getText().trim();
        boolean isValid = false;
        int dashIndex = name.indexOf('.');
        int spaceIndex = name.indexOf(' ', dashIndex);
        int dotIndex = name.indexOf(".");
        int dotspIndex = name.indexOf(' ', dotIndex - 2);
        if (dashIndex > 0 && spaceIndex == dashIndex + 1) {
            if (dotIndex > 0 && dotspIndex > 0) {
                if (name.endsWith(".")) {
               isValid = true;     
                }
            }
        }
            if (isValid) {
            labelname.setForeground(Color.green);
            labelname.setText("Valid Name");
        } else{
            labelname.setForeground(Color.red);
            labelname.setText("Invalid Name");
        }
    }//GEN-LAST:event_CustNameKeyReleased

    private void CustBdayDateKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustBdayDateKeyReleased
    String custbday = CustBdayDate.getText().trim();
        boolean isValid = true;

        if (custbday.charAt(2) == '/' && custbday.charAt(5) == '/' && custbday.length() == 10) {        
        for (int i = 0; i < custbday.length(); i++) {
            char currentChar = custbday.charAt(i);
        
            if(i == 2 && currentChar == '/') {
                continue;
            }
            if(i == 5 && currentChar == '/') {
                continue;
            }
            if (!Character.isDigit(currentChar)) {
            isValid = false;
            break;
            }
        }        
        } else {
            isValid = false;
                }
        
        if (isValid) {
            labelbday.setForeground(Color.green);
            labelbday.setText("Valid Date");
        } else{
            labelbday.setForeground(Color.red);
            labelbday.setText("Invalid Date");
        }
    }//GEN-LAST:event_CustBdayDateKeyReleased

    private void CustAddressKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustAddressKeyReleased
    String customeraddress = CustAddress.getText().trim();
        boolean isValid = false;
        int dashIndex = customeraddress.indexOf('-');
//        int dotIndex = customeraddress.indexOf(".com");
        if (dashIndex > 0)
        isValid = true;

            if (isValid) {
            labeladdress.setForeground(Color.green);
            labeladdress.setText("Valid Address");
        } else{
            labeladdress.setForeground(Color.red);
            labeladdress.setText("Inalid Address");
        }
    }//GEN-LAST:event_CustAddressKeyReleased
public void refresh_my_table(){
   DefaultTableModel tblmodel= (DefaultTableModel) jTable1.getModel();
   tblmodel.setRowCount(0);
   for(int row=0; row<x;row++){
       tblmodel.addRow(cust[row]);
   } //clear or refresh the table
}

public void refresh_orders_table(){
   DefaultTableModel tblmodel= (DefaultTableModel) jTable2.getModel();
   tblmodel.setRowCount(0);
   for(int row=0; row<y;row++){
       tblmodel.addRow(ord[row]);
   } //clear or refresh the table for orders
}
    private void EditBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBTNActionPerformed

            boolean emptytextfield = false;
        if (CustID.getText().length() == 0){
            emptytextfield = true;
        }
        if (CustName.getText().length() == 0){
            emptytextfield = true;
        }
        if (CustAddress.getText().length() == 0){
            emptytextfield = true;
        }
        if (CustPhone.getText().length() == 0){
            emptytextfield = true;
        }        
        if (CustEmail.getText().length() == 0){
            emptytextfield = true;
        }         
        if (CustBdayDate.getText().length() == 0){
            emptytextfield = true;
        }         
        if (CustGender.getText().length() == 0){
            emptytextfield = true;
        }
        
        if (emptytextfield){
            messagebox1("Input cannot be empty", "Error");//code for save button
            return;      
        }
        boolean validation = true;
        if (!labelname.getText().equals("Valid Name")){
            validation = false;
        }
        if (!labeladdress.getText().equals("Valid Address")){
            validation = false;
        }
        if (!labelphone.getText().equals("Good phone number")){
            validation = false;
        }        
        if (!labelemail.getText().equals("Good Email")){
            validation = false;
        }         
        if (!labelbday.getText().equals("Valid Date")){
            validation = false;
        }         
        if (!labelgender.getText().equals("Valid Gender")){
            validation = false;
            }
        if (validation){
            for(int row=0;row<x;row++){
                if(cust[row][0].equals(CustID.getText())){
                    cust[row][1]=CustName.getText();
                    cust[row][2]=CustAddress.getText();
                    cust[row][3]=CustPhone.getText();
                    cust[row][4]=CustEmail.getText();
                    cust[row][6]=CustGender.getText();
                }
            }
            refresh_my_table(); 
            writeToCSV(cust, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\customers.csv");
        } else {
            messagebox2("Invalid Input", "Error");
            refresh_my_table();
        }
//code for Edit Button
    }//GEN-LAST:event_EditBTNActionPerformed

    private void DeleteBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBTNActionPerformed
String idToDelete = CustID.getText();
    
    // Find the index of the row to delete
    int rowToDelete = -1;
    for(int row = 0; row < x; row++) {
        if(cust[row][0].equals(idToDelete)) {
            rowToDelete = row;
            break;
        }
    }
    
    // If the row is found, remove it and shift subsequent rows
    if(rowToDelete != -1) {
        // Shift subsequent rows up
        for (int i = rowToDelete; i < x - 1; i++) {
            cust[i] = cust[i + 1];
        }
        // Clear the last row after shifting
        cust[x - 1] = new String[7];
        x--;
        
        // Write the updated data to the CSV file
        refresh_my_table();
        writeToCSV(cust, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\customers.csv");
    } else {
        // If the row with the given ID is not found, show an error message
        messagebox1("Customer ID not found", "Error");
    }
    }//GEN-LAST:event_DeleteBTNActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
    CustID.setEditable(false); //Code for unable to edit Customer ID
    }//GEN-LAST:event_formWindowOpened
private void updateOrdersTable(String custID) {
    DefaultTableModel orderTableModel = (DefaultTableModel) jTable2.getModel();
    orderTableModel.setRowCount(0); // Clear the existing table

    for (int i = 0; i < y; i++) {
        if (stringtoInt(ord[i][3]) > 0 && ord[i][7].equals(custID)) {
            orderTableModel.addRow(ord[i]); // Add the order to the table
        }
    }
    
    // No need to write to CSV here, as we're only updating the table display
}

private void removeOrder(int index) {
    
    for (int j = index; j < y - 1; j++) {
        ord[j] = ord[j + 1];
    }
    y--; // Decrease the order count
}
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
    String ordersFilePath = "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\orders.csv";
    
        try (BufferedReader br = new BufferedReader(new FileReader(ordersFilePath))) {
            // If the file exists, read data from it and load the orders data
            String[][] csvOrders = readCsvOrders(ordersFilePath);
            loadOrdersData(csvOrders);
        } catch (IOException e) {
            // If the file does not exist or cannot be read, print an error message
            System.out.println("Error reading orders CSV file: " + e.getMessage());
        }
        
        int[] selectRow = jTable1.getSelectedRows();
  int selectedRow = jTable1.getSelectedRow();
    if (selectedRow != -1) {
    custID = jTable1.getValueAt(selectedRow, 0).toString(); 
    CustID.setText(jTable1.getValueAt(selectRow[0], 0).toString());
    CustName.setText(jTable1.getValueAt(selectRow[0], 1).toString());
    CustAddress.setText(jTable1.getValueAt(selectRow[0], 2).toString());
    CustPhone.setText(jTable1.getValueAt(selectRow[0], 3).toString());
    CustEmail.setText(jTable1.getValueAt(selectRow[0], 4).toString());
    CustBdayDate.setText(jTable1.getValueAt(selectRow[0], 5).toString());
    CustGender.setText(jTable1.getValueAt(selectRow[0], 6).toString());

    labelname.setForeground(Color.green);
    labelname.setText("Valid Name");
    labeladdress.setForeground(Color.green);
    labeladdress.setText("Valid Address");
    labelphone.setForeground(Color.green);
    labelphone.setText("Good phone number");
    labelemail.setForeground(Color.green);
    labelemail.setText("Good Email");
    labelbday.setForeground(Color.green);
    labelbday.setText("Valid Date");
    labelgender.setForeground(Color.green);
    labelgender.setText("Valid Gender");
    
    refresh_my_table();
    updateOrdersTable(custID);
    }
//refresh_orders_table();
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
//sszzxcczxczxczxcc
    }//GEN-LAST:event_jTable2MouseClicked
public int incrementProductOrderQuantity(String selectedProductID, int ordQuantity) {
    int currentOrderQuantity = 1; // Initialize current order quantity

    for (int i = 0; i < y; i++) {
        if (ord[i][0].equals(selectedProductID)) { 
            currentOrderQuantity = stringtoInt(ord[i][3]); 
            currentOrderQuantity = currentOrderQuantity + ordQuantity; 
            ord[i][3] = ""+(currentOrderQuantity);
            break; 
        }
    }
    
    // Update the table model with the updated data
    //updateOrdersTable(custID);
    
    // Write the updated data to the CSV file
    //writeToCSV(ord, "c:\\Users\\Jesiah\\Documents\\NetBeansProjects\\CSVs\\orders.csv");
    
    return currentOrderQuantity; 
}


private void messageboxADDButton(String msg, String tittlebar) {
    JOptionPane.showMessageDialog(null,msg,tittlebar,JOptionPane.INFORMATION_MESSAGE);
}

//private void clearOrdersForNewCustomer() {
//    // Clear the ord array
//    for (int i = 0; i < ord.length; i++) {
//        ord[i] = null;
//    }
//    y = 0; // Reset the order count
//    
//    // Clear the orders table
//    DefaultTableModel orderTableModel = (DefaultTableModel) jTable2.getModel();
//    orderTableModel.setRowCount(0); // Clear the existing table
//}


//private String generateOrderIdentifier(String productId, String customerId) {
//    return productId + "-" + customerId;
//}
    private void AddOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddOrderActionPerformed
                                       
    // Check if a customer is selected
    if (custID == null || custID.isEmpty()) {
        // Display an error message or prompt the user to select a customer
        messageboxODLT2("Select a Customer", "Error");
        return;
    }
    
    System.out.println("AddOrderActionPerformed method invoked");
    DefaultTableModel orderTableModel = (DefaultTableModel) jTable2.getModel(); // Orders table

    int[] selectedRows = productsInstance.getSelectedRowIndices();
    String selectedProductID = productsInstance.getValueAt(selectedRows[0], 0);
    
    System.out.println("Selected Product ID: " + selectedProductID);
    
    int productQuantity = stringtoInt(productsInstance.getValueAt(selectedRows[0], 4));
    if (productQuantity == 0) {
        messageboxADDButton("Out of Stock!", "Error");
        return; 
    }
    
    boolean isNewProduct = true;
    
    for (int i = 0; i < y; i++) {
        if (ord[i][0] != null && ord[i][0].equals(selectedProductID) && ord[i][7].equals(custID)) {
            int currentOrderQuantity = stringtoInt(ord[i][3]);
            System.out.println("Current order quantity before increment: " + currentOrderQuantity);
            currentOrderQuantity++; 
            System.out.println("Current order quantity after increment: " + currentOrderQuantity);
            ord[i][3] = "" + currentOrderQuantity; // Update the order quantity
            int productCost = stringtoInt(productsInstance.getValueAt(selectedRows[0], 5));
            int totalCost = currentOrderQuantity * productCost;
            ord[i][6] = "" + totalCost; // Update the total cost
            isNewProduct = false;
            // Update the orders table
            updateOrdersTable(custID);
            break;
        }
    }

    productsInstance.decrementProductQuantity(selectedProductID);
    
    if (isNewProduct) {
        String[] rowData = new String[8];
        
        rowData[0] = selectedProductID; // Use the selected product ID as the order identifier
        rowData[1] = productsInstance.getValueAt(selectedRows[0], 1);
        rowData[2] = productsInstance.getValueAt(selectedRows[0], 2);
        rowData[3] = "1";
        rowData[4] = productsInstance.getValueAt(selectedRows[0], 5);
        rowData[5] = productsInstance.getValueAt(selectedRows[0], 6);
        rowData[6] = "" + (stringtoInt(rowData[4]) * 1);
        rowData[7] = custID; // Associate the order with the selected customer
        
        // Add the new row data to the end of the ord array
        ord[y] = rowData;
        
        // Add the new row data to the table model
        orderTableModel.addRow(rowData); 
        
        // Increment the order count
        y++;
        
        // Update the orders table
        updateOrdersTable(custID);

    }
    
    // Write the updated orders to the CSV file
    writeToCSVOrders(ord, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\orders.csv");
    }//GEN-LAST:event_AddOrderActionPerformed
//
    private void DeleteOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteOrderActionPerformed
                                      
    DefaultTableModel orderTableModel = (DefaultTableModel) jTable2.getModel(); // Orders table
    if (custID != null && !custID.isEmpty()) {
        int selectedRow = jTable2.getSelectedRow();
        if (selectedRow != -1) {
            String selectedProductID = jTable2.getValueAt(selectedRow, 0).toString();
            int currentOrderQuantity = stringtoInt(jTable2.getValueAt(selectedRow, 3).toString()); 
            if (currentOrderQuantity > 0) {
                currentOrderQuantity--;

                for (int i = 0; i < y; i++) {
                    if (ord[i][0].equals(selectedProductID) && ord[i][7].equals(custID)) {
                        ord[i][3] = ""+(currentOrderQuantity);
                        int productCost = stringtoInt(jTable2.getValueAt(selectedRow, 4).toString());
                        int totalCost = currentOrderQuantity * productCost;
                        ord[i][6] = ""+(totalCost);
                        break;
                    }
                }
                
                // Increment product quantity after removing an order
                productsInstance.incrementProductQuantity(selectedProductID);

                if (currentOrderQuantity == 0) {
                    orderTableModel.removeRow(selectedRow);
                    
                    for (int i = 0; i < y; i++) {
                        if (ord[i][0].equals(selectedProductID) && ord[i][7].equals(custID)) {
                            for (int j = i; j < y - 1; j++) {
                                ord[j] = ord[j + 1];
                            }
                            ord[y - 1] = null;
                            break; 
                        }
                    }
                    y--; 
                }
            }
        } else {
            messageboxODLT("Select an Order", "Error");
        }
    } else {
        messageboxODLT2("Select a Customer", "Error");
    }
    updateOrdersTable(custID);
    writeToCSVOrders(ord, "c:\\Users\\gscigtanloc\\Documents\\NetBeansProjects\\CSVs\\orders.csv");
    }//GEN-LAST:event_DeleteOrderActionPerformed
    private void messageboxODLT(String msg, String tittlebar) {
        JOptionPane.showMessageDialog(null,msg,tittlebar,JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void messageboxODLT2(String msg, String tittlebar) {
        JOptionPane.showMessageDialog(null,msg,tittlebar,JOptionPane.INFORMATION_MESSAGE);
    }
    private void CustEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustEmailActionPerformed

    private void CustNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustNameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddOrder;
    private javax.swing.JTextField CustAddress;
    private javax.swing.JTextField CustBdayDate;
    private javax.swing.JTextField CustEmail;
    private javax.swing.JTextField CustGender;
    private javax.swing.JTextField CustID;
    private javax.swing.JTextField CustName;
    private javax.swing.JTextField CustPhone;
    private javax.swing.JButton DeleteBTN;
    private javax.swing.JButton DeleteOrder;
    private javax.swing.JButton EditBTN;
    private javax.swing.JMenuItem ProductsMenuItem;
    private javax.swing.JButton SaveBTN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel labeladdress;
    private javax.swing.JLabel labelbday;
    private javax.swing.JLabel labelemail;
    private javax.swing.JLabel labelgender;
    private javax.swing.JLabel labelname;
    private javax.swing.JLabel labelphone;
    // End of variables declaration//GEN-END:variables
}
